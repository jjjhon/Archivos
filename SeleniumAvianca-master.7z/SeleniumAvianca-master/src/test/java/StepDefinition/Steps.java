package StepDefinition;

import java.io.FileReader;
import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;	

public class Steps {				

    WebDriver driver;			
    String baseUrl = "https://www.avianca.com/co/en/";
    String origen, ciudad, nombre, apellido, correo, celular, diaNacimiento, mesNacimiento, yearNacimiento;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    
    @Given("^Ingreso a la pagina$")					
    public void abrir_pagina_avianca() throws Throwable							
    {	
    	//--------------------------------------------------------------------------------------------------------------------------
    	//Lectura de archivo plano
    	String texto="";
    	try {
            FileReader entrada=new FileReader(System.getProperty("user.dir") + "//archivoPlano//Usuarios.txt");
                int c=0;
                while(c!=-1) {
                    c=entrada.read();
                    char letra=(char)c;
                    texto+=letra;
                }
                entrada.close();
        } catch (IOException e) {
            System.out.println("No se ha encontrado el archivo");
        }
    	String[] arrayDatos = texto.split(":");
    	
    	String datosPersona = arrayDatos[0];
    	String[] arrayDatosPersona = datosPersona.split(";");

    	origen = arrayDatosPersona[0];
    	ciudad = arrayDatosPersona[1];
    	nombre = arrayDatosPersona[2];
    	apellido = arrayDatosPersona[3];
    	correo = arrayDatosPersona[4];
    	celular = arrayDatosPersona[5];
    	diaNacimiento = arrayDatosPersona[6];
    	mesNacimiento = arrayDatosPersona[7];
    	yearNacimiento = arrayDatosPersona[8];
    	
    	System.out.println(origen);
    	System.out.println(ciudad);
    	System.out.println(nombre);
    	System.out.println(apellido);
    	System.out.println(correo);
    	System.out.println(celular);
    	System.out.println(diaNacimiento);
    	System.out.println(mesNacimiento);
    	System.out.println(yearNacimiento);
    	//--------------------------------------------------------------------------------------------------------------------------
    	
    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//drivers//chromedriver.exe");				
        driver = new ChromeDriver();				
        driver.manage().window().maximize();			
        driver.get(baseUrl);		
        
    }		
    
    @Given("^Ingreso a la pagina2$")					
    public void abrir_pagina_avianca_dos() throws Throwable							
    {	
    	//--------------------------------------------------------------------------------------------------------------------------
    	//Lectura de archivo plano
    	String texto="";
    	try {
            FileReader entrada=new FileReader(System.getProperty("user.dir") + "//archivoPlano//Usuarios.txt");
                int c=0;
                while(c!=-1) {
                    c=entrada.read();
                    char letra=(char)c;
                    texto+=letra;
                }
                entrada.close();
        } catch (IOException e) {
            System.out.println("No se ha encontrado el archivo");
        }
    	String[] arrayDatos = texto.split(":");
    	
    	String datosPersona = arrayDatos[1];
    	String[] arrayDatosPersona = datosPersona.split(";");

    	origen = arrayDatosPersona[0];
    	ciudad = arrayDatosPersona[1];
    	nombre = arrayDatosPersona[2];
    	apellido = arrayDatosPersona[3];
    	correo = arrayDatosPersona[4];
    	celular = arrayDatosPersona[5];
    	diaNacimiento = arrayDatosPersona[6];
    	mesNacimiento = arrayDatosPersona[7];
    	yearNacimiento = arrayDatosPersona[8];
    	
    	System.out.println(origen);
    	System.out.println(ciudad);
    	System.out.println(nombre);
    	System.out.println(apellido);
    	System.out.println(correo);
    	System.out.println(celular);
    	System.out.println(diaNacimiento);
    	System.out.println(mesNacimiento);
    	System.out.println(yearNacimiento);
    	//--------------------------------------------------------------------------------------------------------------------------
    	
    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//drivers//chromedriver.exe");				
        driver = new ChromeDriver();				
        driver.manage().window().maximize();			
        driver.get(baseUrl);
    }		

    @When("^Seleccione el vuelo$")					
    public void seleccionar_vuelo() throws Throwable 							
    {	
    	WebDriverWait wait1 = new WebDriverWait(driver, 20);
    	WebElement deals = wait1.until(ExpectedConditions.elementToBeClickable(By.linkText("Deals and offers")));
    	deals.click();
    	
    	WebElement internacional = wait1.until(ExpectedConditions.elementToBeClickable(By.linkText("INTERNATIONAL FLIGHTS")));
    	internacional.click();
    	
    	WebElement destino = wait1.until(ExpectedConditions.elementToBeClickable(By.partialLinkText(ciudad)));
    	destino.click();
    	
    	WebElement fechaOrigen = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/div[1]/form/div[2]/div[4]/div[1]/div[1]/table/tbody/tr/td[1]/div[3]/table/tbody/tr[5]/td[5]")));
    	fechaOrigen.click();

    	WebElement returnDate = wait1.until(ExpectedConditions.elementToBeClickable(By.name("pbFechaRegreso")));
    	returnDate.click();
    			
    	WebElement fechaDestino = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/div[1]/form/div[2]/div[4]/div[1]/div[2]/table/tbody/tr/td[2]/div[3]/table/tbody/tr[4]/td[4]")));
    	fechaDestino.click();
    	
    	WebElement comprar = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/div[1]/form/div[2]/div[4]/div[2]/div/div[2]/div[6]/div[2]/button")));
    	comprar.click();
    	
    	WebElement continuar = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"w23\"]/span")));
    	continuar.click();
    	
    	WebElement vuelo = wait1.until(ExpectedConditions.elementToBeClickable(By.id("table-bound0-cell11-available-content")));
    	vuelo.click();
    	
    	WebElement siguiente = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"w67\"]/span")));
    	siguiente.click();
    	
    	WebElement tabla = driver.findElement(By.id("tpl3_bound1-table-flightline-details1"));
    	new Actions(driver).moveToElement(tabla).perform(); 
    	
    	WebElement vueloVuelta = wait1.until(ExpectedConditions.elementToBeClickable(By.id("tpl3_table-bound1-cell10-available")));
    	vueloVuelta.click();

    	WebElement next = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"w141\"]/span")));
    	next.click();
    }
    
    @And("^Ingresar los datos personales$")	
    public void ingreso_datos_personales() throws Throwable 							
    {	

    	WebDriverWait wait1 = new WebDriverWait(driver, 20);
    	wait1.until(ExpectedConditions.elementToBeClickable(By.name("IDEN_FirstName")));
    	driver.findElement(By.name("IDEN_FirstName")).sendKeys(nombre);
    	driver.findElement(By.name("IDEN_LastName")).sendKeys(apellido);
    	driver.findElement(By.name("DateMonth")).sendKeys(mesNacimiento);
    	driver.findElement(By.name("DateDay")).sendKeys(diaNacimiento);
    	driver.findElement(By.name("DateYear")).sendKeys(yearNacimiento);
    	driver.findElement(By.name("Email")).sendKeys(correo);
    	driver.findElement(By.name("PhoneHome")).sendKeys(celular);
    	driver.findElement(By.name("EmailConfirm")).sendKeys(correo);
    	
    	WebElement politicas = wait1.until(ExpectedConditions.elementToBeClickable(By.name("generalPrivacyPolicy")));
    	new Actions(driver).moveToElement(politicas).perform(); 
    	politicas.click();
    	
    	WebElement continuar = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"w103\"]/span")));
    	new Actions(driver).moveToElement(continuar).perform(); 
    	continuar.click();
    	
    	Thread.sleep(5000);
    	JavascriptExecutor js = (JavascriptExecutor) driver;

    	js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    	js.executeScript("window.scrollTo(0, document.body.scrollIntoView)");
    	WebElement continuar2 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"w33\"]")));

    	new Actions(driver).moveToElement(continuar2).perform();
    	continuar2.click();
    	
    }
    
    @Then("^Llegar a la seleccion de pago$")					
    public void seccion_metodo_pago() throws Throwable 							
    {  
       Thread.sleep(10000);
       String tituloPago = driver.getTitle();
       String tituloEsperado = "Make payment | Avianca";
       Assert.assertEquals(tituloEsperado, tituloPago);
       System.out.println("Caso Exitoso T�tulo Secci�n de pago: " + tituloPago);
       driver.quit();
    }		
}	